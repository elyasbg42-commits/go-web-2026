# GameDex

Catalogue de jeux vidéo et de leurs tournois, en Go (`net/http` + `html/template`), alimenté par la mini API du cours.

## Lancer

Deux terminaux.

```
# Terminal 1, à la racine du dépôt : la mini API (port 8081)
go run ./api

# Terminal 2, dans le dossier gamedex/ : GameDex (port 8080)
cd gamedex
go run ./cmd/gamedex
```

Options : `-port 9000` (port de GameDex), `-api http://localhost:8081` (adresse de la mini API).

GameDex charge les jeux et les tournois **une seule fois au démarrage**. Si la mini API ne répond pas à ce moment-là, il s'arrête avec un message clair.

## Routes

| Route | Rôle |
| --- | --- |
| `GET /` | Accueil |
| `GET /jeux` | Liste des jeux. Filtres facultatifs : `?q=cel&genre=course` |
| `GET /jeux/{id}` | Fiche d'un jeu, ses tournois et une carte Leaflet. 400 si l'id n'est pas un nombre, 404 si le jeu n'existe pas |
| `POST /recherche` | Bonus : le formulaire est transmis à la mini API (`/api/games?q=&genre=`). 502 si l'API ne répond pas |
| `GET /api/jeux?q=&genre=` | Bonus : la même liste filtrée, en JSON (utilisée par la recherche instantanée) |
| `GET /static/...` | CSS et JavaScript |
| toute autre adresse | Page 404 |

## Organisation

```
gamedex/
├── go.mod
├── cmd/gamedex/main.go     charge les données, lance le serveur
├── internal/
│   ├── api/                parle à la mini API (client avec timeout de 3 s)
│   ├── catalog/            les règles : Filter, FindGame, GroupByGame, Genres (+ tests)
│   └── server/             routes et handlers
└── web/
    ├── templates/          les pages HTML (html/template)
    └── static/             CSS et JavaScript (filtre.js, carte.js)
```

Qui connaît qui : `api` ne connaît ni HTML ni navigateur ; `catalog` ne connaît ni HTTP ni HTML ; `server` lit la requête, appelle `catalog`, affiche un template ; `web/` ne contient aucune règle.

## Vérifier

```
go vet ./...
go test ./...
```
