// Mini TP 3 : GameDex appelle la mini API.
// À lancer depuis le dossier gamedex/ : go run . (ou go run . -port 9000)
// La mini API doit tourner : go run ./api (à la racine du dépôt).
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"time"
)

// Il n'y a pas encore de vraies données : on suppose 12 jeux (ids 1 à 12).
const nombreDeJeux = 12

const baseURL = "http://localhost:8081"

// Pour l'étape 5 du TP : remplacer par "/api/broken" puis "/api/slow".
const cheminJeux = "/api/games"

// Un client avec timeout : une API qui ne répond jamais ne doit pas figer GameDex.
var client = &http.Client{Timeout: 3 * time.Second}

// Game a la forme du JSON renvoyé par /api/games.
type Game struct {
	ID     int      `json:"id"`
	Name   string   `json:"name"`
	Year   int      `json:"year"`
	Studio string   `json:"studio"`
	Genres []string `json:"genres"`
}

// Tournament a la forme du JSON renvoyé par /api/tournaments.
type Tournament struct {
	ID     int     `json:"id"`
	GameID int     `json:"gameId"`
	Name   string  `json:"name"`
	City   string  `json:"city"`
	Date   string  `json:"date"`
	Lat    float64 `json:"lat"`
	Lng    float64 `json:"lng"`
}

// FetchGames demande la liste des jeux à la mini API.
// Les trois vérifications : réponse reçue, bon code, JSON lisible.
func FetchGames() ([]Game, error) {
	resp, err := client.Get(baseURL + cheminJeux)
	if err != nil {
		return nil, fmt.Errorf("appel de %s : %w", cheminJeux, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("l'API a répondu %d sur %s", resp.StatusCode, cheminJeux)
	}

	var games []Game
	if err := json.NewDecoder(resp.Body).Decode(&games); err != nil {
		return nil, fmt.Errorf("JSON illisible pour %s : %w", cheminJeux, err)
	}
	return games, nil
}

// FetchTournaments demande tous les tournois à la mini API.
func FetchTournaments() ([]Tournament, error) {
	const chemin = "/api/tournaments"

	resp, err := client.Get(baseURL + chemin)
	if err != nil {
		return nil, fmt.Errorf("appel de %s : %w", chemin, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("l'API a répondu %d sur %s", resp.StatusCode, chemin)
	}

	var tournaments []Tournament
	if err := json.NewDecoder(resp.Body).Decode(&tournaments); err != nil {
		return nil, fmt.Errorf("JSON illisible pour %s : %w", chemin, err)
	}
	return tournaments, nil
}

func main() {
	port := flag.Int("port", 8080, "port d'écoute du serveur")
	flag.Parse()

	games, err := FetchGames()
	if err != nil {
		log.Fatal("Impossible de charger les jeux : ", err)
	}
	tournaments, err := FetchTournaments()
	if err != nil {
		log.Fatal("Impossible de charger les tournois : ", err)
	}

	// Les tournois rangés par jeu, une seule fois : byGame[3] est ensuite instantané.
	byGame := make(map[int][]Tournament)
	for _, t := range tournaments {
		byGame[t.GameID] = append(byGame[t.GameID], t)
	}
	for _, g := range games {
		fmt.Printf("%-22s %d  %d tournoi(s)\n", g.Name, g.Year, len(byGame[g.ID]))
	}

	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", accueil)
	mux.HandleFunc("GET /jeux", listeJeux)
	mux.HandleFunc("GET /jeux/{id}", detailJeu)

	// Fichiers statiques : /static/css/style.css -> static/css/style.css
	fs := http.FileServer(http.Dir("static"))
	mux.Handle("GET /static/", http.StripPrefix("/static/", fs))

	addr := fmt.Sprintf(":%d", *port)
	fmt.Printf("GameDex sur http://localhost%s\n", addr)
	log.Fatal(http.ListenAndServe(addr, mux))
}

// accueil renvoie une page HTML qui utilise notre CSS (bonus).
func accueil(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprint(w, `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>GameDex</title>
  <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
  <header><a href="/">GameDex</a></header>
  <main>
    <h1>Bienvenue sur GameDex</h1>
    <p>Le catalogue des jeux et de leurs tournois.</p>
    <p><a href="/jeux">Voir les jeux</a></p>
  </main>
</body>
</html>
`)
}

func listeJeux(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Liste des jeux")
}

func detailJeu(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil || id < 1 {
		http.Error(w, "identifiant invalide", http.StatusBadRequest)
		return
	}
	if id > nombreDeJeux {
		http.NotFound(w, r)
		return
	}
	fmt.Fprintf(w, "Fiche du jeu %d\n", id)
}
