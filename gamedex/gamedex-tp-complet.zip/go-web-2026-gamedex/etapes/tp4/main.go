// Mini TP 4 : les vraies pages de GameDex (templates html/template).
// À lancer depuis le dossier gamedex/ : go run . (ou go run . -port 9000)
// La mini API doit tourner : go run ./api (à la racine du dépôt).
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"strconv"
	"time"
)

const baseURL = "http://localhost:8081"

// Pour l'étape 5 du TP : remplacer par "/api/broken" puis "/api/slow".
const cheminJeux = "/api/games"

// Un client avec timeout : une API qui ne répond jamais ne doit pas figer GameDex.
var client = &http.Client{Timeout: 3 * time.Second}

// Game a la forme du JSON renvoyé par /api/games.
type Game struct {
	ID     int      `json:"id"`
	Name   string   `json:"name"`
	Year   int      `json:"year"`
	Studio string   `json:"studio"`
	Genres []string `json:"genres"`
}

// Tournament a la forme du JSON renvoyé par /api/tournaments.
type Tournament struct {
	ID     int     `json:"id"`
	GameID int     `json:"gameId"`
	Name   string  `json:"name"`
	City   string  `json:"city"`
	Date   string  `json:"date"`
	Lat    float64 `json:"lat"`
	Lng    float64 `json:"lng"`
}

// FetchGames demande la liste des jeux à la mini API.
// Les trois vérifications : réponse reçue, bon code, JSON lisible.
func FetchGames() ([]Game, error) {
	resp, err := client.Get(baseURL + cheminJeux)
	if err != nil {
		return nil, fmt.Errorf("appel de %s : %w", cheminJeux, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("l'API a répondu %d sur %s", resp.StatusCode, cheminJeux)
	}

	var games []Game
	if err := json.NewDecoder(resp.Body).Decode(&games); err != nil {
		return nil, fmt.Errorf("JSON illisible pour %s : %w", cheminJeux, err)
	}
	return games, nil
}

// FetchTournaments demande tous les tournois à la mini API.
func FetchTournaments() ([]Tournament, error) {
	const chemin = "/api/tournaments"

	resp, err := client.Get(baseURL + chemin)
	if err != nil {
		return nil, fmt.Errorf("appel de %s : %w", chemin, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("l'API a répondu %d sur %s", resp.StatusCode, chemin)
	}

	var tournaments []Tournament
	if err := json.NewDecoder(resp.Body).Decode(&tournaments); err != nil {
		return nil, fmt.Errorf("JSON illisible pour %s : %w", chemin, err)
	}
	return tournaments, nil
}

// --- Données chargées une seule fois, au démarrage ---

var (
	games       []Game
	tournaments []Tournament
	byGame      = make(map[int][]Tournament) // les tournois rangés par jeu
)

// --- Templates : lus une fois au démarrage, Must plante tout de suite si faute ---

var tmpl = template.Must(template.ParseGlob("templates/*.html"))

// Une struct par page : ce dont le template a besoin.
type AccueilPage struct {
	Title string
}

type ListePage struct {
	Title string
	Games []Game
	Query string
}

type JeuPage struct {
	Title       string
	Game        Game
	Tournaments []Tournament
}

type ErreurPage struct {
	Title   string
	Code    int
	Message string
}

func main() {
	port := flag.Int("port", 8080, "port d'écoute du serveur")
	flag.Parse()

	var err error
	games, err = FetchGames()
	if err != nil {
		log.Fatal("Impossible de charger les jeux : ", err)
	}
	tournaments, err = FetchTournaments()
	if err != nil {
		log.Fatal("Impossible de charger les tournois : ", err)
	}
	for _, t := range tournaments {
		byGame[t.GameID] = append(byGame[t.GameID], t)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", accueil)
	mux.HandleFunc("GET /jeux", listeJeux)
	mux.HandleFunc("GET /jeux/{id}", detailJeu)
	// "GET /" attrape tout le reste : c'est notre page 404.
	mux.HandleFunc("GET /", introuvable)

	// Fichiers statiques : /static/css/style.css -> static/css/style.css
	fs := http.FileServer(http.Dir("static"))
	mux.Handle("GET /static/", http.StripPrefix("/static/", fs))

	addr := fmt.Sprintf(":%d", *port)
	fmt.Printf("GameDex sur http://localhost%s (%d jeux, %d tournois)\n", addr, len(games), len(tournaments))
	log.Fatal(http.ListenAndServe(addr, mux))
}

// show remplit un template et envoie la page avec le bon code.
// On écrit d'abord dans un buffer : si le template échoue, on peut encore répondre 500
// proprement au lieu d'envoyer une page à moitié construite.
func show(w http.ResponseWriter, status int, name string, data any) {
	var buf bytes.Buffer
	if err := tmpl.ExecuteTemplate(&buf, name, data); err != nil {
		log.Println("template", name, ":", err)
		http.Error(w, "erreur interne", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(status)
	buf.WriteTo(w)
}

// showError affiche erreur.html avec le code HTTP correspondant.
func showError(w http.ResponseWriter, status int, message string) {
	show(w, status, "erreur.html", ErreurPage{
		Title:   fmt.Sprintf("Erreur %d", status),
		Code:    status,
		Message: message,
	})
}

func accueil(w http.ResponseWriter, r *http.Request) {
	show(w, http.StatusOK, "accueil.html", AccueilPage{Title: "GameDex"})
}

func introuvable(w http.ResponseWriter, r *http.Request) {
	showError(w, http.StatusNotFound, "Cette page n'existe pas.")
}

func listeJeux(w http.ResponseWriter, r *http.Request) {
	// html/template échappe la valeur : <script> s'affiche comme du texte.
	q := r.URL.Query().Get("q")
	show(w, http.StatusOK, "liste.html", ListePage{Title: "Les jeux", Games: games, Query: q})
}

func detailJeu(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil || id < 1 {
		showError(w, http.StatusBadRequest, "L'identifiant du jeu doit être un nombre positif.")
		return
	}
	for _, g := range games {
		if g.ID == id {
			show(w, http.StatusOK, "jeu.html", JeuPage{Title: g.Name, Game: g, Tournaments: byGame[id]})
			return
		}
	}
	showError(w, http.StatusNotFound, "Ce jeu n'existe pas.")
}
