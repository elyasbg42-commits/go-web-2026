// Mini TP 2 : le premier serveur de GameDex.
// À lancer depuis le dossier gamedex/ : go run . (ou go run . -port 9000)
package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"strconv"
)

// Il n'y a pas encore de vraies données : on suppose 12 jeux (ids 1 à 12).
const nombreDeJeux = 12

func main() {
	port := flag.Int("port", 8080, "port d'écoute du serveur")
	flag.Parse()

	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", accueil)
	mux.HandleFunc("GET /jeux", listeJeux)
	mux.HandleFunc("GET /jeux/{id}", detailJeu)

	// Fichiers statiques : /static/css/style.css -> static/css/style.css
	fs := http.FileServer(http.Dir("static"))
	mux.Handle("GET /static/", http.StripPrefix("/static/", fs))

	addr := fmt.Sprintf(":%d", *port)
	fmt.Printf("GameDex sur http://localhost%s\n", addr)
	log.Fatal(http.ListenAndServe(addr, mux))
}

// accueil renvoie une page HTML qui utilise notre CSS (bonus).
func accueil(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprint(w, `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>GameDex</title>
  <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
  <header><a href="/">GameDex</a></header>
  <main>
    <h1>Bienvenue sur GameDex</h1>
    <p>Le catalogue des jeux et de leurs tournois.</p>
    <p><a href="/jeux">Voir les jeux</a></p>
  </main>
</body>
</html>
`)
}

func listeJeux(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Liste des jeux")
}

func detailJeu(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil || id < 1 {
		http.Error(w, "identifiant invalide", http.StatusBadRequest)
		return
	}
	if id > nombreDeJeux {
		http.NotFound(w, r)
		return
	}
	fmt.Fprintf(w, "Fiche du jeu %d\n", id)
}
