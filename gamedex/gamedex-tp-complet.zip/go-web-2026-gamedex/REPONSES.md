# Réponses et suivi des mini TP · GameDex

Tout le code a été exécuté et vérifié avec la vraie mini API du dépôt `louvelmathieu/go-web-2026` (Go 1.24).

## Où est quoi

| Dossier | Contenu |
| --- | --- |
| `gamedex/` | La version finale : mini TP 5 + TP bonus. À copier dans le dossier `gamedex/` de votre fork |
| `etapes/tp2/` | GameDex à la fin du mini TP 2 |
| `etapes/tp3/` | … du mini TP 3 |
| `etapes/tp4/` | … du mini TP 4 |

Chaque dossier `etapes/tpN/` est un dossier `gamedex/` complet : pour garder un historique Git propre, copiez-les un par un dans `gamedex/` de votre fork, avec un commit après chaque copie (messages plus bas). Les mini TP 5 et bonus sont réunis dans le dossier `gamedex/` final.

---

## Mini TP 1 · Explorer la mini API (pas de code)

| Question | Réponse |
| --- | --- |
| 3. `/api/games/999` | **404** · `{"error":"jeu introuvable"}` |
| 3. `/api/games/abc` | **400** · `{"error":"l'identifiant doit être un nombre"}` |
| 4. Tournois du jeu 4 (Street Fighter 6) | **4 tournois** : Marseille (Fight Night Marseille), Paris (Combo Breaker EU), Tokyo (Rising Dragon), Bruxelles (Hadoken Series) |
| 5. Jeux de course (`?genre=course`) | Rocket League, Trackmania, Mario Kart 8 Deluxe |
| 5. Jeux sortis en 2018 (`?year=2018`) | Celeste, Dead Cells |
| 6. `/api/stats` sans clé | **401** · clé absente ou inconnue |
| 6. `/api/stats` avec la clé `eleve` | **403** · clé reconnue, pas le droit |
| 6. `/api/stats` avec la clé `prof` | **200** · `{"games":12,"tournaments":20}` |
| Bonus. `/api/broken` | **500** · `{"error":"panne simulée"}` |
| Bonus. `/api/slow` | **200**, mais après **5 secondes** (5,005 s mesurées) |

Dans Swagger (`localhost:8081/api/docs`), la clé se saisit avec le bouton **Authorize**, en haut de la page.

Exercice « Espionner un vrai site » (slide 15) : ce n'est pas un mini TP et il dépend du site que vous choisissez, je ne peux pas le faire à votre place. La méthode : F12 → onglet Réseau → recharger. Le nombre de requêtes est en bas de l'onglet, la requête de la page est la première ligne (type `document`, code 200, `Content-Type: text/html`), et une adresse inexistante renvoie en général un 404.

## Mini TP 2 · Premier serveur

Commit : `Mini TP 2 : premier serveur`

Codes relevés (onglet Réseau, ou `curl -i`) :

| URL | Code |
| --- | --- |
| `/`, `/jeux`, `/jeux/3` | 200 |
| `/jeux/abc`, `/jeux/0` | 400 |
| `/jeux/999` | 404 |
| `/static/css/style.css` | 200 (`text/css`) |
| `POST /jeux` | 405 (automatique grâce à `"GET /jeux"`) |

`go run . -port 9000` change le port (8080 par défaut). La page d'accueil renvoie du HTML qui charge `/static/css/style.css` (bonus).

## Mini TP 3 · GameDex appelle la mini API

Commit : `Mini TP 3 : appel de l'API`

Au démarrage, GameDex affiche chaque jeu avec son année et son nombre de tournois (par exemple `Rocket League 2015 3 tournoi(s)`, `Hades 2020 0 tournoi(s)`).

Étape 4 et 5, messages obtenus :

| Situation | Message |
| --- | --- |
| Mini API coupée | `Impossible de charger les jeux : appel de /api/games : Get "http://localhost:8081/api/games": dial tcp 127.0.0.1:8081: connect: connection refused` |
| `/api/broken` à la place de `/api/games` | `Impossible de charger les jeux : l'API a répondu 500 sur /api/broken` |
| `/api/slow` à la place de `/api/games` | `Impossible de charger les jeux : appel de /api/slow : … (Client.Timeout exceeded while awaiting headers)` après 3 s |

Dans les trois cas, le programme s'arrête avec `log.Fatal` : pas de panique, pas de trace Go. Le cas `/api/broken` montre le piège du cours : Go ne renvoie **aucune** erreur (`err == nil`), c'est la vérification du `StatusCode` qui l'attrape.

## Mini TP 4 · Les vraies pages

Commit : `Mini TP 4 : templates et pages d'erreur`

- `header.html` / `footer.html` partagés, `liste.html`, `jeu.html`, `accueil.html`, `erreur.html`
- `/jeux/3` : fiche + tournois (nom, ville, date) ; `/jeux/2` (Hades) affiche « Aucun tournoi prévu »
- Pages d'erreur avec le bon code : 400 (`/jeux/abc`), 404 (`/jeux/999` et toute adresse inconnue)
- Le cas « API indisponible » (502) est géré par `POST /recherche` du TP bonus, car les données sont chargées au démarrage
- Test du XSS : `/jeux?q=<script>alert("x")</script>` s'affiche comme du texte, le code source contient `&lt;script&gt;alert(&#34;x&#34;)&lt;/script&gt;`. Avec `text/template`, le script s'exécuterait

## Mini TP 5 · Ranger GameDex

Commit : `Mini TP 5 : structure cmd/internal/web`

Vérifications demandées :

- Plus aucun appel à l'API dans `server`, à une exception près : `POST /recherche` du TP bonus, qui appelle `api.SearchGames` comme le montre le cours (slide 66)
- Plus aucun template dans `catalog` (il n'importe que `strings`, `slices` et `api`)
- Les jeux et les tournois sont chargés une seule fois, dans `cmd/gamedex/main.go`
- `go vet ./...` ne signale rien ; `go test ./...` passe (tests de `catalog` et de `api`)

## Mini TP bonus · GameDex devient interactif

Commit : `Mini TP bonus : filtres, carte, recherche instantanée`

1. `/jeux` : champ de recherche et liste des genres dans un formulaire GET (`?q=…&genre=…`), le genre choisi reste sélectionné après rechargement
2. Côté Go : `catalog.Filter(games, genre, q)`
3. Fiche d'un jeu : carte Leaflet de ses tournois (centrée automatiquement sur les marqueurs, pas de carte s'il n'y a aucun tournoi)
4. Onglet Réseau : un filtre par formulaire envoie `GET /jeux?q=…&genre=…` (la page entière revient, rechargée) ; la recherche instantanée envoie `GET /api/jeux?q=…&genre=…` à chaque frappe (du JSON, sans rechargement). Aucun des deux n'appelle la mini API
5. Bonus POST : `POST /recherche` (corps `q=ce&genre=indé`) → GameDex appelle `GET /api/games?genre=ind%C3%A9&q=ce`, visible dans le terminal de la mini API. API coupée : page 502. `GET /recherche` : 405
6. Bonus fetch : `filtre.js` + `GET /api/jeux`, qui réutilise le même `catalog.Filter`

À noter : le texte venant de l'API est toujours inséré avec `textContent` côté JavaScript (liste et bulles de la carte), jamais en HTML brut.

La carte charge Leaflet et les tuiles OpenStreetMap depuis internet : il faut une connexion dans le navigateur.

---

## Avant de rendre

```
git add .
git commit -m "Mini TP 5 : structure cmd/internal/web"
git push
```

Vérifiez sur GitHub que votre fork est bien **Public**, et relisez le code avant de le rendre : vous devez pouvoir expliquer chaque fichier.
